package application.enums;
/**
* These are the values which the Status can take, the Status enum. 
*
* @author Miguel Álvarez Valiente, Alejandro Benimeli Miranda, Álvaro Castillo García
* */
public enum Status {
	WAITING,
	ACCEPTED,
	REJECTED
}
